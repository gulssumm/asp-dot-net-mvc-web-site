﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DotNetCore_First.Migrations
{
    public partial class AddStudentToDatabase : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
